const JsConfuser = require('js-confuser');
const fs = require("fs");

let handler = async (m, { alip, example, usedPrefix, command, isCreator, Reply }) => {
  // ❌ Cek registrasi user
  if (!isRegistered(m.sender) && !['daftar', 'register'].includes(command) && !isCreator)
    return Reply(`❌ *AKSES DITOLAK*\n\nKamu belum terdaftar.\nKetik *${usedPrefix}daftar* untuk akses semua fitur bot.`, {
      contextInfo: {
        externalAdReply: {
          title: '🚫 Belum Terdaftar',
          body: 'Daftar dulu biar bisa akses fitur lengkap.',
          thumbnailUrl: global.image.menu,
          sourceUrl: global.namaSaluran,
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    });

    if (!isPrem(m.sender) && !isCreator) return Reply('❌ Khusus user premium! ketik *.prem* buat upgrade');

  // Pastikan ada file yang di-quote
  if (!m.quoted) return Reply("Reply file .js");

  // Cek ekstensi file .js
  if (!m.quoted.message?.documentMessage?.fileName.endsWith(".js")) {
    return Reply("Reply file .js");
  }

  let media = await m.quoted.download();
  let filename = m.quoted.message.documentMessage.fileName;

  // Simpan sementara file JS
  await fs.writeFileSync(`./@hardenc${filename}.js`, media);
  Reply("*Memproses encrypt..*");

  await JsConfuser.obfuscate(
    await fs.readFileSync(`./@hardenc${filename}.js`).toString(),
    {
      target: "node",
      preset: "high",
      compact: true,
      minify: true,
      flatten: true,
      identifierGenerator: function () {
        const originalString = "/*alipclutch/*^/*($break)*/" + "/*alipclutch/*^/*($break)*/";
        function hapusKarakterTidakDiinginkan(input) {
          return input.replace(/[^a-zA-Z]/g, '');
        }
        function stringAcak(panjang) {
          let hasil = '';
          const karakter = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
          const panjangKarakter = karakter.length;
          for (let i = 0; i < panjang; i++) {
            hasil += karakter.charAt(Math.floor(Math.random() * panjangKarakter));
          }
          return hasil;
        }
        return hapusKarakterTidakDiinginkan(originalString) + stringAcak(2);
      },
      renameVariables: true,
      renameGlobals: true,
      stringEncoding: 0.01,
      stringSplitting: 0.1,
      stringConcealing: true,
      stringCompression: true,
      duplicateLiteralsRemoval: true,
      shuffle: { hash: false, booleans: false },
      stack: false,
      controlFlowFlattening: false,
      opaquePredicates: false,
      deadCode: false,
      dispatcher: false,
      rgf: false,
      calculator: false,
      hexadecimalNumbers: false,
      movedDeclarations: true,
      objectExtraction: true,
      globalConcealing: true,
    }
  )
    .then(async (obfuscated) => {
      // Simpan hasil obfuscate
      await fs.writeFileSync(`./@hardenc${filename}.js`, obfuscated);

      // Kirim file ke chat
      await alip.sendMessage(
        m.chat,
        {
          document: fs.readFileSync(`./@hardenc${filename}.js`),
          mimetype: "application/javascript",
          fileName: filename,
          caption: "Sukses! Type:\nString",
        },
        { quoted: m }
      );
    })
    .catch((e) => Reply("Error :" + e));

  // Hapus file sementara
  await fs.unlinkSync(`./@hardenc${filename}.js`);
};

handler.command = ["enchard", "enc"];

module.exports = handler;